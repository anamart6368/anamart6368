
import pandas as pd

# Load the dataset
file_path = "tiktok_event_data.xlsx"
df = pd.read_excel(file_path)

# Test Case 1: Check data format
assert df['event_time'].dtype == 'object', "Event time should be a string in 'YYYY-MM-DD HH:MM:SS' format."
assert pd.api.types.is_numeric_dtype(df['value']), "Value column should be numeric."
assert df['event_type'].isnull().sum() == 0, "Event type should not have null values."

# Test Case 2: Total value calculation
total_value = df['value'].sum()
assert total_value == 400000, f"Total value mismatch: {total_value} != 400000"

# Test Case 3: Event type count
event_counts = df['event_type'].value_counts()
expected_counts = {'ViewContent': 1, 'AddToCart': 1, 'InitiateCheckout': 1, 'Search': 1}
assert all(event_counts == pd.Series(expected_counts)), "Event type counts mismatch."

# Test Case 4: Time-based analysis
df['event_time'] = pd.to_datetime(df['event_time'])
assert df['event_time'].dtype == 'datetime64[ns]', "Event time should be converted to datetime."

print("All test cases passed!")
